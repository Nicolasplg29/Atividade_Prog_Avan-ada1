package com.Atividade.Veiculo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeiculoApplicationTests {

	@Test
	void contextLoads() {
	}

}
